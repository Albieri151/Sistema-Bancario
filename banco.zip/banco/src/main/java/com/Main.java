package com;

import java.util.Scanner;

import com.banco.Administrador;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Boolean Salir = true;
        Administrador Admin = new Administrador();
        do {
            System.out.println("\t\t\tBienvenido a Banesco Panama");
            System.out.println("\n\n1. Iniciar sesion");
            System.out.println("2. Salir");
            Integer opcion = sc.nextInt();

            switch (opcion) {

                case 1 -> {

                    sc.nextLine();
                    System.out.print("Ingrese el usuario o correo: ");
                    String Usuario = sc.nextLine().toLowerCase();
                    if (Admin.BuscarUsuarios(Usuario)) {
                        if (Usuario.equals("admin")) {
                            Boolean Salir1 = true;
                            do {
                                System.out.println("\n1. Transacciones");
                                System.out.println("2. Registrar un usuario nuevo");
                                System.out.println("3. Tasa de cambio");
                                System.out.println("4. Lista de Usuarios");
                                System.out.println("5. Estadistica");
                                System.out.println("6. Salir");
                                opcion = sc.nextInt();

                                switch (opcion) {
                                    case 1 -> {
                                        Admin.VerHistorial();
                                    }
                                    case 2 -> {
                                        Admin.AgregarUsuario();
                                    }
                                    case 3 -> {
                                        System.out.println("1. Ver tasa cambiaria");
                                        System.out.println("2. Modificar tasa cambiaria");
                                        opcion = sc.nextInt();
                                        if (opcion == 1) {
                                            System.out.println("\nTasa cambiaria en: "+ Admin.getTasaCambiaria());
                                        } else {
                                            System.out.print("Ingrese la nueva tasa cambiaria: ");
                                            Double NuevaTasa = sc.nextDouble();
                                            Admin.setTasaCambiaria(NuevaTasa);
                                        }
                                    }
                                    case 4 -> {
                                        Admin.ListadoDeUsuarios();
                                    }
                                    case 5 -> {
                                        Admin.BalanceBancario();
                                        System.out.println("Total de usuarios: " + Admin.TotalDeUsuarios());
                                        System.out.println("Dinero Disponible en el banco: " + Admin.DineroEnBanco() + "$ | " + Admin.DineroEnBanco() + "bsf");
                                    }
                                    case 6 -> {
                                        Salir1 = false;
                                    }
                                    default -> System.out.println("Error!! Opcion no disponible.");
                                }
                            } while (Salir1);

                        }else {
                            Boolean Salir1 = true;
                            do { 
                                System.out.println("\n1. Depositar Dinero");
                                System.out.println("2. Transferencia Bancaria");
                                System.out.println("3. Retirar Dinero");
                                System.out.println("4. Realice un Pago Movil");
                                System.out.println("5. Ver Informacion");
                                System.out.println("6. Ver Historial de Transacciones");
                                System.out.println("7. Salir");
                                Integer Opcion = sc.nextInt();

                                switch (Opcion) {
                                    case 1 -> {
                                        Admin.Depositar(Admin.DevolverPosicionUser(Usuario));
                                    }
                                    case 2 -> {
                                        Admin.Transferencia(Admin.DevolverPosicionUser(Usuario));
                                    }
                                    case 3 -> {
                                        Admin.Debitar(Admin.DevolverPosicionUser(Usuario));
                                    }
                                    case 4 -> {
                                        Admin.PagoMovil(Admin.DevolverPosicionUser(Usuario));
                                    }
                                    case 5 -> {
                                        Admin.VerInformacion(Admin.DevolverPosicionUser(Usuario));
                                    }
                                    case 6 -> {
                                        Admin.VerHistorialUser(Admin.DevolverPosicionUser(Usuario));
                                    }
                                    case 7 -> Salir1 = false;

                                    default ->  System.out.println("Error opcion no disponible.");
                                        
                                }

                            } while (Salir1);
                        }

                    } else System.out.println("Usuario o Clave Invalidos\n");

                }

                case 2 -> {
                    Salir = false;
                }

                default -> System.out.println("Error!! Coloque nuevamente la opcion.\n");
            }

        } while (Salir);
    }
}