package com.banco;

import java.util.ArrayList;
import java.util.Scanner;

public class Administrador extends UsuariosBanco {

    ArrayList<UsuariosComun> ListaDeUsuarios = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    private Double TasaCambiaria = 40.0;

    public Double getTasaCambiaria() {
        return TasaCambiaria;
    }

    public void setTasaCambiaria(Double TasaCambiaria) {
        this.TasaCambiaria = TasaCambiaria;
    }

    public Boolean UsuariosAdmin() {
            
            System.out.print("Ingrese la clave: ");
            String Clave = sc.nextLine().toLowerCase();
            Boolean Verificado = Clave.equals("admin");
            return Verificado;
    }

    public Boolean BuscarUsuarios(String UsuarioBuscado) {

        if (UsuarioBuscado.equals("admin")) {
            return UsuariosAdmin();
        }
        for (UsuariosComun Usuario1 : ListaDeUsuarios) {

            Boolean Verificado = Usuario1.getUsuario().equals(UsuarioBuscado) || Usuario1.getCorreoElectronico().equals(UsuarioBuscado);

            if (Verificado) {
                System.out.print("\nIngrese la clave: ");
                String Clave = sc.nextLine().toLowerCase();
                Verificado = Usuario1.getClave().equals(Clave);
                return Verificado;
            }
        }
        return false;
    }

    @Override
    public void VerHistorial() {
        if (!ListaDeUsuarios.isEmpty()) {
            for (UsuariosComun Usuario1 : ListaDeUsuarios) {
                Usuario1.VerHistorial();
            } 
        }else System.out.println("No cuenta con transacciones realizadas.");
        
    }

    public void AgregarUsuario() {
        UsuariosComun User = new UsuariosComun();

        System.out.print("Ingrese su nombre: ");
        String Nombre = sc.nextLine().toLowerCase();
        User.setNombre(Nombre);

        System.out.print("Ingrese su apellido: ");
        String Apellido = sc.nextLine().toLowerCase();
        User.setApellido(Apellido);

        System.out.print("Ingrese su correo electronico: ");
        String CorreoElectronico = sc.nextLine().toLowerCase();
        User.setCorreoElectronico(CorreoElectronico);

        System.out.print("Ingrese su numero telefonico: ");
        Long NumeroDeTelefono = sc.nextLong();
        User.setTelefono(NumeroDeTelefono);

        System.out.print("Ingrese su cedula: ");
        Integer Cedula = sc.nextInt();
        User.setCedula(Cedula);

        sc.nextLine();
        System.out.print("Ingrese su usuario: ");
        String Usuario = sc.nextLine().toLowerCase();
        User.setUsuario(Usuario);

        System.out.print("Ingrese su clave: ");
        String Clave = sc.nextLine().toLowerCase();
        User.setClave(Clave);

        ListaDeUsuarios.add(User);
    }

    public void ListadoDeUsuarios() {
        if (!ListaDeUsuarios.isEmpty()) {
            for (UsuariosComun UsuarioBanco : ListaDeUsuarios) {
                System.out.println( "Usuario: " + UsuarioBanco.getUsuario() + " | Nombre: " + UsuarioBanco.getNombre() + " | Apellido: "
                + UsuarioBanco.getApellido() + " | Cedula: " + UsuarioBanco.getCedula() + " | Estado de cuenta: " + UsuarioBanco.getCuenta());
            }
        }else System.out.println("No cuenta con usuarios registrados");
        
    }

    public void BalanceBancario() {
        Double TotalTransferencias = 0.0 , TotalDepositos = 0.0, TotalDebitos = 0.0;

        for (UsuariosComun User : ListaDeUsuarios) {
            TotalTransferencias += User.TotalTransferencias("transferencia");
            TotalDepositos += User.TotalTransferencias("deposito");
            TotalDebitos += User.TotalTransferencias("retiro");
        }
        System.out.println("\nTotal de transferencias: " + TotalTransferencias);
        System.out.println("Total de depositos: " + TotalDepositos);
        System.out.println("Total de debitos: " + TotalDebitos);
    }
    
    public Integer TotalDeUsuarios() {
        return ListaDeUsuarios.size();
    }

    public Double DineroEnBanco() {
        Double TotalDeDinero = 0.0;
        for (UsuariosComun User : ListaDeUsuarios) {
            TotalDeDinero += User.getCuenta();
        }
        return TotalDeDinero;
    }

    public void Transferencia(Integer UsuarioDebito) {
        sc.nextLine();
        System.out.print("Ingrese el usuario o correo: ");
        String BuscarUsuario = sc.nextLine().toLowerCase();
        Boolean Busqueda = true;
        for (UsuariosComun User : ListaDeUsuarios) {

            if (User.getUsuario().equals(BuscarUsuario) || User.getCorreoElectronico().equals(BuscarUsuario)) {

                System.out.print("Ingrese su Cedula: ");
                Integer Cedula = sc.nextInt();

                if (User.getCedula().equals(Cedula)) {

                    System.out.print("Ingrese el monto: ");
                    Double Monto = sc.nextDouble();

                    while (Monto <= 0 && Monto > ListaDeUsuarios.get(UsuarioDebito).getCuenta()) {
                        System.out.println("Monto invalido, reingreselo: ");
                        Monto = sc.nextDouble();
                    }
                    User.DepositarDinero(Monto, "transferencia");
                    ListaDeUsuarios.get(UsuarioDebito).RetirarDinero(Monto*-1, "transferencia");

                } else
                    System.out.println("Cedula invalida");
            } else
                Busqueda = false;
        }
        if (Busqueda) {
            System.out.println("Usuario no encontrado");
        }
    }

    public Integer DevolverPosicionUser(String User) {
        Integer ContarUsuarios = 0;
        for (UsuariosComun User1 : ListaDeUsuarios) {
            if (User1.getUsuario().equals(User) || User1.getCorreoElectronico().equals(User)) {
                return ContarUsuarios;
            }
            ContarUsuarios++;
        }
        return 0;
    }

    public void Debitar(Integer buscar) {
        System.out.print("Ingrese el monto a retirar: ");
        Double Retiro = sc.nextDouble();
        ListaDeUsuarios.get(buscar).RetirarDinero(Retiro*-1, "retiro");
    }

    public void Depositar(Integer buscar) {
        System.out.print("Ingrese el monto a depositar: ");
        Double Deposito = sc.nextDouble();
        ListaDeUsuarios.get(buscar).DepositarDinero(Deposito, "deposito");
    }

    public void PagoMovil(Integer UserBuscado) {
        System.out.print("Ingrese la cedula: ");
        Integer Cedula = sc.nextInt();
        Boolean Encontrar = true;
        for (UsuariosComun User : ListaDeUsuarios) {

            if (User.getCedula().equals(Cedula)) {
                System.out.println("Ingrese el numero de telefono: ");
                Long NumeroTelefonico = sc.nextLong();
                if (User.getTelefono().equals(NumeroTelefonico)) {
                    System.out.println("Ingrese el monto: ");
                    Double Monto = sc.nextDouble();
                    while (Monto <= 0 && Monto > ListaDeUsuarios.get(UserBuscado).getCuenta()) {
                        System.out.println("Monto invalido, reingreselo: ");
                        Monto = sc.nextDouble();
                    }
                    User.DepositarDinero(Monto, "pago movil recibido de "+ ListaDeUsuarios.get(UserBuscado).getCedula());
                    ListaDeUsuarios.get(UserBuscado).RetirarDinero(Monto*-1, "pago movil realizado a: " + User.getCedula());
                    Encontrar = false;
                    break;
                } else
                    System.out.println("Numero no encontrado");
            }

        }
        if (Encontrar) {
            System.out.println("Cedula no encontrada");
        }
    }

    public void VerInformacion(Integer User) {
        ListaDeUsuarios.get(User).VerInformacion();
    }

    public void VerHistorialUser(Integer User) {
        ListaDeUsuarios.get(User).VerHistorial();
    }
}
