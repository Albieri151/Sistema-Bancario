package com.banco;

import java.util.ArrayList;
import java.util.Scanner;

public class UsuariosComun extends UsuariosBanco {
    ArrayList<String> Movimientos = new ArrayList<>();
    ArrayList<Double> Historial = new ArrayList<>();
    ArrayList<Double> ControlDeCuenta = new ArrayList<>();

    Scanner sc = new Scanner(System.in);

    @Override
    public void VerHistorial() {
        Integer Contador = 0;
        for (Double Movimientos1 : Historial) {
            System.err.println("Nombre: " + getNombre() +" | Apellido: "+ getApellido() + " | Movimiento: " + Movimientos.get(Contador) 
            + " | Cantidad: "+ Movimientos1 + "$" + " | Estado de cuenta : " + ControlDeCuenta.get(Contador));
            Contador++;
        }
    }

    public Double TotalTransferencias(String Busqueda){
        Double MovimientoBancario = 0.0;
        Integer Control = 0;
        for (String MovimientosUsuarios : Movimientos) {
            if (MovimientosUsuarios.equals(Busqueda)) {
                switch (Busqueda) {
                    case "transferencia"-> {
                        if (Historial.get(Control)>=0) {
                            MovimientoBancario += Historial.get(Control);
                        }
                    }
                    case "retiro"->{
                        MovimientoBancario += Historial.get(Control);
                    }
                    case "deposito" ->{
                        MovimientoBancario += Historial.get(Control);
                    }
                }
            }
            Control++;
        }
        return MovimientoBancario;
    }

    public void DepositarDinero(Double Deposito, String Transferencia){
        
        while (Deposito <= 0) {
            System.out.println("Monto invalido, reingreselo: ");
            Deposito = sc.nextDouble();
        }
        Movimientos.add(Transferencia);
        Historial.add(Deposito);
        Cuenta+=Deposito;
        ControlDeCuenta.add(getCuenta());
    }

    public void RetirarDinero(Double Retiro, String Transaccion){
        while (Retiro < Cuenta*-1) {
            System.out.println("Monto invalido, reingreselo: ");
            Retiro = sc.nextDouble();
            Retiro*=-1;
        }
        Historial.add(Retiro);
        Movimientos.add(Transaccion);
        Cuenta+=Retiro;
        ControlDeCuenta.add(getCuenta());
    }

    public void VerInformacion(){
        System.out.println("Nombre: " + getNombre() + " | Apellido: " + getApellido() + " | Cedula: " + getCedula() + " | Estado de cuenta: " + getCuenta());
    }
}
